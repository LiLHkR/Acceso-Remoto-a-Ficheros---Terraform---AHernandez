#!/bin/bash
export DEBIAN_FRONTEND=noninteractive

# Instalación
apt-get update
apt-get install -y mariadb-server

# Configuración para permitir conexiones remotas
sed -i 's/bind-address            = 127.0.0.1/bind-address            = 0.0.0.0/' /etc/mysql/mariadb.conf.d/50-server.cnf
systemctl restart mariadb

# Base de datos y usuarios
mysql -u root <<EOF
CREATE DATABASE vsftpd;
USE vsftpd;

CREATE TABLE accounts (
 id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(30) NOT NULL,
 pass VARCHAR(100) NOT NULL,
 UNIQUE (username)
);

INSERT INTO accounts (username, pass) VALUES('alumno', ENCRYPT('1234'));

-- Permitimos acceso desde cualquier IP de la red interna (%)
CREATE USER 'vsftpd_user'@'%' IDENTIFIED BY 'db_password';
GRANT SELECT ON vsftpd.accounts TO 'vsftpd_user'@'%';
FLUSH PRIVILEGES;
EOF