#!/bin/bash
export DEBIAN_FRONTEND=noninteractive

# Instalar paquetes
apt-get update
apt-get install -y vsftpd libpam-mysql openssl default-mysql-client

# Crear usuario sistema mapeado
groupadd -g 2001 ftpuser
useradd -u 2001 -g 2001 -d /home/ftpuser -s /sbin/nologin ftpuser
mkdir /home/ftpuser
chown ftpuser:ftpuser /home/ftpuser
chmod 550 /home/ftpuser

# Certificado SSL
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
    -keyout /etc/ssl/private/vsftpd.pem \
    -out /etc/ssl/private/vsftpd.pem \
    -subj "/C=ES/ST=Spain/L=Madrid/O=IT/CN=ftp-server-aws"

# OBTENER LA IP PÚBLICA REAL DE AWS (Truco Cloud)
PUBLIC_IP=$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4)

# Configuración vsftpd
mv /etc/vsftpd.conf /etc/vsftpd.conf.bak

cat <<EOT > /etc/vsftpd.conf
listen=YES
listen_ipv6=NO
anonymous_enable=NO
local_enable=YES
write_enable=YES
dirmessage_enable=YES
use_localtime=YES
xferlog_enable=YES
connect_from_port_20=YES

# JAULA
chroot_local_user=YES
allow_writeable_chroot=YES
secure_chroot_dir=/var/run/vsftpd/empty

# USUARIOS VIRTUALES
guest_enable=YES
guest_username=ftpuser
user_sub_token=\$USER
local_root=/home/ftpuser/\$USER
virtual_use_local_privs=YES
pam_service_name=vsftpd_mysql

# MODO PASIVO (Con IP dinámica de AWS)
pasv_enable=YES
pasv_min_port=40000
pasv_max_port=40100
pasv_address=\$PUBLIC_IP

# SSL FORZOSO
ssl_enable=YES
allow_anon_ssl=NO
force_local_data_ssl=YES
force_local_logins_ssl=YES
ssl_tlsv1=YES
ssl_sslv2=NO
ssl_sslv3=NO
rsa_cert_file=/etc/ssl/private/vsftpd.pem
rsa_private_key_file=/etc/ssl/private/vsftpd.pem
utf8_filesystem=YES
EOT

# Configuración PAM (Usando la variable ${db_ip} que viene de Terraform)
cat <<EOT > /etc/pam.d/vsftpd_mysql
auth required pam_mysql.so user=vsftpd_user passwd=db_password host=${db_ip} db=vsftpd table=accounts usercolumn=username passwdcolumn=pass crypt=1
account required pam_mysql.so user=vsftpd_user passwd=db_password host=${db_ip} db=vsftpd table=accounts usercolumn=username passwdcolumn=pass crypt=1
EOT

# Carpeta y permisos del usuario alumno
mkdir -p /home/ftpuser/alumno/archivos
chown -R ftpuser:ftpuser /home/ftpuser/alumno
chmod 550 /home/ftpuser/alumno
chmod 775 /home/ftpuser/alumno/archivos

systemctl restart vsftpd